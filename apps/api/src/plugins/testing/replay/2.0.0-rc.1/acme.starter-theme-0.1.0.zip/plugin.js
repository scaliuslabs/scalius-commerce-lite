// ../../../../../../../../Users/arob/Desktop/open/scalius-commerce-lite/packages/plugin-sdk/src/manifest-types.ts
function defineManifest(manifest2) {
  return manifest2;
}

// ../../../../../../../../Users/arob/Desktop/open/scalius-commerce-lite/packages/shared/src/plugins/api-version.ts
var PLUGIN_API_VERSION = "2026-10";

// ../../../../../../../../Users/arob/Desktop/open/scalius-commerce-lite/packages/shared/src/plugins/scopes.ts
var PRODUCTS_READ = ["products.view", "categories.view", "collections.view", "attributes.view"];
var INVENTORY_READ = ["inventory.view"];
var OBJECTS_READ = ["objects.view"];
var PLUGIN_SCOPES = {
  /** Products, variants with their stock totals and per-location levels, collections, categories, brands and attributes. */
  read_products: { rbac: PRODUCTS_READ, staff: "products.view" },
  /**
   * Create, edit, trash and restore products, variants, collections,
   * categories, brands and attributes; set product custom fields. Never
   * changes stock (`write_inventory`). Permanently deletes only trashed
   * products, categories, brands and collections the app itself created
   * (`dashboard.resources.app_content.delete`), never the store's own.
   */
  write_products: {
    rbac: [
      ...PRODUCTS_READ,
      "products.create",
      "products.edit",
      "products.delete",
      "products.restore",
      "categories.create",
      "categories.edit",
      "categories.delete",
      "categories.restore",
      "collections.create",
      "collections.edit",
      "collections.delete",
      "collections.restore",
      "collections.toggle_status",
      "attributes.create",
      "attributes.edit",
      "attributes.delete"
    ],
    staff: "products.edit"
  },
  /** Stock levels per location, locations, suppliers and transfers; purchase orders also need `read_product_costs`. */
  read_inventory: { rbac: INVENTORY_READ, staff: "inventory.view" },
  /**
   * Adjust and set stock (on hand, per location), including the quantities a
   * product or SKU write sets; manage locations, suppliers and transfers
   * (purchase orders also need `read_product_costs`).
   */
  write_inventory: { rbac: [...INVENTORY_READ, "products.adjust_stock", "inventory.manage"], staff: "products.adjust_stock" },
  /** Orders, their lines, payments, shipments, returns and timeline; abandoned checkouts. Contact fields need the protected data scopes. */
  read_orders: { rbac: ["orders.view"], staff: "orders.view" },
  /**
   * Create orders, change their status and details, add timeline notes, set
   * order custom fields; request, approve, receive and cancel item returns
   * (receiving restocks what comes back, through the stock ledger).
   */
  write_orders: { rbac: ["orders.view", "orders.create", "orders.edit", "orders.change_status"], staff: "orders.edit" },
  /**
   * Record money received against an invoice (pay-later) order: a bank
   * transfer, cheque or cash. Sensitive: a recorded payment settles the order
   * with no money passing through the store. Gift cards and downloads on an
   * order an app marked paid wait for staff to release a review hold.
   * Charging a saved card is `write_payment_methods`.
   */
  write_payments: { rbac: ["orders.view", "orders.record_payment"], staff: "orders.record_payment", sensitive: true },
  /**
   * Charge a customer's saved payment method for an order with money due,
   * without the customer (a subscription renewal, through its provider), and
   * capture or void an authorized payment. Only the methods kept for this
   * app's own purchase option: an app never sees or charges a method another
   * app (or staff) kept. Lists and removes those methods (brand, last four
   * digits and expiry; never the provider's reference). Sensitive: it takes
   * a buyer's money while they are away.
   */
  write_payment_methods: {
    rbac: ["orders.view", "orders.charge_saved_methods"],
    staff: "orders.charge_saved_methods",
    sensitive: true
  },
  /**
   * Give money back on an order (`refunds.create`): through the payments it
   * came from or as store credit, never to a destination the app names, with
   * the order lines it is for. Sensitive: it moves money out of the store.
   */
  write_refunds: { rbac: ["orders.view", "orders.refund"], staff: "orders.refund", sensitive: true },
  /** Hand over order lines, create and void fulfilments and courier shipments. */
  write_fulfillments: { rbac: ["orders.view", "orders.manage_shipments"], staff: "orders.manage_shipments" },
  /**
   * Give a buyer the download or licence keys their paid order line bought
   * (as the store's automatic delivery would), give back access that was
   * taken away, and take it away (`digital_access.grant`, `.revoke`). Taking
   * it away cannot be undone by the buyer: the consent screen marks it
   * destructive. Reading an order's access is `read_orders`.
   */
  write_digital_access: { rbac: ["orders.view", "orders.manage_digital_access"], staff: "orders.manage_digital_access" },
  /**
   * Issue the app's coverage of units of an order line as the store's own
   * warranty records (`warranties.issue`), which buyers see and claim like
   * any warranty, and void units' coverage when they are cancelled,
   * refunded or returned (`warranties.void`). Voiding ends a buyer's cover:
   * the consent screen marks it destructive. Reading an order's warranties
   * is `read_orders`.
   */
  write_warranties: { rbac: ["orders.view", "orders.manage_warranties"], staff: "orders.manage_warranties" },
  /** Customers, their tags, saved segments and marketing consent; email, text or push a customer by id (`ctx.messaging`). Contact fields need the protected data scopes. */
  read_customers: { rbac: ["customers.view"], staff: "customers.view" },
  /** Create and edit customers, their tags and custom fields; save and change customer segments (not one a live discount or price list uses, without that area's write scope). */
  write_customers: { rbac: ["customers.view", "customers.create", "customers.edit"], staff: "customers.edit" },
  /** Send marketing email and SMS to customers who agreed to receive it. The platform resolves the address; the app never sees it. */
  write_marketing: { rbac: ["marketing.send"], staff: "marketing.send" },
  /**
   * Email and text any address from the store's sender (`ctx.messaging` with
   * any `to`). Without it an app reaches customers by id, the store's staff
   * and the addresses in its declared `messaging.recipients` fields only.
   * Sensitive: mail from the store's own domain to anyone. Confers no RBAC.
   */
  send_messages_any: { rbac: [], staff: "marketing.send", sensitive: true },
  /** Buyers' and recipients' names. */
  read_customer_names: { rbac: [], staff: "customers.view", protects: "name" },
  /** Buyers' email addresses. */
  read_customer_emails: { rbac: [], staff: "customers.view", protects: "email" },
  /** Buyers' and recipients' phone numbers. */
  read_customer_phones: { rbac: [], staff: "customers.view", protects: "phone" },
  /** Street addresses: address lines, company and neighbourhood (the region is not protected). */
  read_customer_addresses: { rbac: [], staff: "customers.view", protects: "address" },
  /** Discounts and their rules. */
  read_discounts: { rbac: ["discounts.view"], staff: "discounts.view" },
  /** Create, edit, pause, activate and archive discounts. */
  write_discounts: {
    rbac: ["discounts.view", "discounts.create", "discounts.edit", "discounts.delete", "discounts.toggle_status"],
    staff: "discounts.edit"
  },
  /** Content pages. */
  read_content: { rbac: ["pages.view"], staff: "pages.view" },
  /** Create, edit, publish and trash content pages; set their custom fields. */
  write_content: { rbac: ["pages.view", "pages.create", "pages.edit", "pages.delete", "pages.publish"], staff: "pages.edit" },
  /** The store's object types and records outside the app's own namespace (`custom.*`). */
  read_objects: { rbac: OBJECTS_READ, staff: "objects.view" },
  /** Create, edit and delete records of the store's object types. */
  write_objects: { rbac: [...OBJECTS_READ, "objects.edit"], staff: "objects.edit" },
  /** Files in the media library. */
  read_files: { rbac: ["media.view"], staff: "media.view" },
  /** Import files from an HTTPS address, rename, move and trash them; permanently delete trashed files the app itself imported. */
  write_files: { rbac: ["media.view", "media.upload", "media.delete", "media.manage_folders"], staff: "media.upload" },
  /** Gift cards: balances, transactions, owners and recipients (the code stays masked; recipient contacts need the protected data scopes). */
  read_gift_cards: { rbac: ["gift_cards.view"], staff: "gift_cards.view" },
  /**
   * Issue gift cards, adjust their balances, disable, enable and change
   * expiry. Sensitive: it creates and moves stored value the store owes, so
   * what one app adds a day stays within the merchant's limit. The app never
   * sees a card's code; the store delivers it to the owning customer only,
   * and an app never moves a card with a balance to another owner.
   */
  write_gift_cards: { rbac: ["gift_cards.view", "gift_cards.manage"], staff: "gift_cards.manage", sensitive: true },
  /**
   * Create, edit and delete the app's own webhook subscriptions: endpoints on
   * its approved hosts, for the event topics and the customer data its grant
   * already covers. Never sees or changes the store's other webhooks.
   * Sensitive: store events leave the store.
   */
  write_webhooks: { rbac: ["webhooks.view", "webhooks.manage"], staff: "webhooks.manage", sensitive: true },
  /**
   * Store settings: business details, web addresses, markets, languages,
   * delivery zones and their rates, tax regions and custom field definitions.
   */
  read_settings: { rbac: ["settings.general.view", "settings.shipping_methods.view", "taxes.view"], staff: "settings.general.view" },
  /**
   * Read the theme and change its shared draft: apply the app's own
   * template (its look and homepage) and set section settings, each under
   * the draft revision it read, with a restore point. Never publishes: what
   * buyers see changes only when staff publish the draft. Sensitive: the
   * draft is the next storefront. Confers `settings.theme.edit` only, never
   * the store's business, country or media settings.
   */
  write_themes: { rbac: ["settings.theme.edit"], staff: "settings.theme.edit", sensitive: true },
  /**
   * Read menus, create them, replace their links (up to three levels) and
   * publish them. Never chooses where a menu shows (header, footer).
   * Sensitive: a published menu placed in the header or footer changes what
   * buyers see at once.
   */
  write_navigation: { rbac: ["settings.header.edit"], staff: "settings.header.edit", sensitive: true },
  /** Add and update delivery places (a place dataset) through the place import; never delete them. */
  write_places: {
    rbac: ["settings.delivery_locations.view", "settings.delivery_locations.import"],
    staff: "settings.delivery_locations.import"
  },
  /**
   * What the store pays for stock: purchase-order costs (unit costs,
   * shipping, other charges and tax) and the SKU unit costs a receipt may
   * move. Alone it reaches no stable operation (a bundled first-party app
   * also reads inventory valuation with it): beside `read_inventory` it reads
   * purchase orders, beside `write_inventory` it drafts, orders, receives and
   * cancels them, and an app's webhooks for purchase orders need it.
   * Sensitive: costs and margins are the merchant's trade secrets.
   */
  read_product_costs: { rbac: ["products.view_costs"], staff: "products.view_costs", sensitive: true },
  /**
   * The inbox: threads (order, store and chat-channel threads) with their
   * messages, staff notes included, and `conversation.message_received`.
   * The contact's name and address need `read_customer_names` and
   * `read_customer_phones`. Sensitive: buyers' own words.
   */
  read_conversations: { rbac: ["conversations.view"], staff: "conversations.view", sensitive: true },
  /**
   * Reply in a thread and add staff notes (`conversations.create_message`):
   * a public reply reaches the buyer by the thread's own way (email for
   * storefront threads, the chat channel for channel threads), as a staff
   * reply does, and names the app. Sensitive: it speaks for the store.
   */
  write_conversations: { rbac: ["conversations.view", "conversations.reply"], staff: "conversations.reply", sensitive: true },
  /**
   * Send money to payees (`payouts.create`) through a payout provider the
   * merchant installed, and read the payouts the app sent (never another
   * app's). Sensitive: it moves money out of the store.
   */
  write_payouts: { rbac: ["payouts.manage"], staff: "payouts.manage", sensitive: true },
  /**
   * The staff directory: each staff member's id, name, roles and whether
   * they are active, so an app attributes work (who rang up a sale). Never an
   * email, a phone, sign-in details or what they may do.
   */
  read_staff: { rbac: ["staff.view"], staff: "staff.view" },
  /** Product reviews: ratings, text, photos, replies and moderation state. The reviewer's name needs `read_customer_names`. */
  read_reviews: { rbac: ["reviews.view"], staff: "reviews.view" },
  /** Import reviews (a reviews app, a move from another platform) and publish, reject or hide them. */
  write_reviews: { rbac: ["reviews.view", "reviews.moderate"], staff: "reviews.moderate" },
  /** Sales numbers over a bounded period: orders, revenue, average order value and, where the store records them, sessions. */
  read_analytics: { rbac: ["dashboard.analytics"], staff: "dashboard.analytics" }
};
var PLUGIN_SCOPE_NAMES = Object.keys(PLUGIN_SCOPES);

// ../../../../../../../../Users/arob/Desktop/open/scalius-commerce-lite/packages/plugin-sdk/src/index.ts
function definePlugin(definition) {
  return definition;
}
function provider(kind) {
  return (implementation) => Object.freeze({ ...implementation, kind });
}
var definePaymentProvider = provider("payment");
var defineCourierProvider = provider("courier");
var defineSmsProvider = provider("sms");
var defineEmailProvider = provider("email");
var defineCourierHistoryProvider = provider("courier_history");
var defineTaxProvider = provider("tax");
var defineTranslationProvider = provider("translation");
var defineAiProvider = provider("ai");
var defineMessagingProvider = provider("messaging");
var definePushProvider = provider("push");
var defineSearchProvider = provider("search");
var defineAddressProvider = provider("address");
var defineFxProvider = provider("fx");
var defineIdentityProvider = provider("identity");
var definePayoutProvider = provider("payout");

// src/index.ts
var manifest = defineManifest({
  id: "acme.starter-theme",
  name: "Starter Theme",
  version: "0.1.0",
  apiVersion: PLUGIN_API_VERSION,
  description: "A storefront theme: a header, footer and product card that draw each store's own name, logo, menu and products, a product row section, and a ready-made template.",
  author: { name: "acme" },
  tagline: "A clean storefront theme",
  icon: "assets/icon.svg",
  categories: ["store-design"],
  storefront: {
    sections: [{
      type: "product_row",
      name: "Product row",
      description: "A heading and a row of products from a source the merchant picks.",
      settings: [
        { key: "heading", label: "Heading", type: "text", default: "New arrivals", maxLength: 80 },
        // A source, never product paths: each store fills it with its own products.
        { key: "products", label: "Products", type: "products", default: "newest", limit: 8 },
        // No default: a link default is the same on every store. The merchant picks a category or collection.
        { key: "link", label: "Link", type: "link", help: "Where Shop all goes, such as a category. Empty: no link." },
        { key: "link_label", label: "Link text", type: "text", default: "Shop all", maxLength: 40 }
      ]
    }],
    skins: [
      {
        id: "header",
        target: "header",
        name: "Starter Theme header",
        description: "The store's logo (or name), its menu, search, account and cart.",
        settings: [{ key: "sticky", label: "Stay at the top while scrolling", type: "boolean", default: true }]
      },
      {
        id: "footer",
        target: "footer",
        name: "Starter Theme footer",
        description: "The store's menus, policies and contact details.",
        settings: [{ key: "tagline", label: "Tagline", type: "text", default: "", maxLength: 120 }]
      },
      { id: "card", target: "product_card", name: "Starter Theme product card", description: "Photo, title, price and a quick add.", settings: [] }
    ],
    templates: [{
      id: "starter_theme",
      name: "Starter Theme",
      description: "The header, footer and product card, a row of the newest products and the store's popular products.",
      // The theme document version these values are written for; stores upgrade them from here.
      themeVersion: 16,
      theme: {
        apps: {
          skins: {
            header: { app: "acme.starter-theme/header", values: {} },
            footer: { app: "acme.starter-theme/footer", values: {} },
            product_card: { app: "acme.starter-theme/card", values: {} }
          }
        },
        sections: [
          { id: "starter_theme-new", type: "app", version: 1, settings: { app: "acme.starter-theme/product_row", values: { heading: "New arrivals", products: "newest" } } },
          // A core section with a product source: every store fills it from its own catalogue.
          { id: "starter_theme-popular", type: "product_rail", version: 1, settings: { title: "Popular products", source: { kind: "popular" }, limit: 8 } }
        ]
      }
    }],
    islands: [{ name: "menu", description: "Closes the phone menu on Escape and after a link is chosen." }],
    stylesheet: true
  }
});
var src_default = definePlugin({ manifest });
export {
  src_default as default,
  manifest
};
//# scalius-assets {"assets/icon.svg":"5d00deaf234691f9d91746ffc830eb3266ed994714ea5e623659195ccbcf8a62"}
//# scalius-storefront {"storefront.js":"84d60cbe9b9098535c6fae0728e7676328b5a2e0e4b443244845c8cf2524e671","islands/menu.js":"6156ff16d9c4f21618b35a61fd2b2fd407b5d912b4ed75dd412b65febd9aaa73","styles.css":"7eea9eeab5c183cf8adb2ab2e542a0c061804de797a77067a89db8c0f8a9d05b","public/placeholder.svg":"af4c9783306c0810367cef9a76c67d538628abe366b37454d96f25758b5424f8"}
