// ../../../../../../../../Users/arob/Desktop/open/scalius-commerce-lite/packages/shared/src/plugins/api-version.ts
var PLUGIN_API_VERSION = "2026-10";

// ../../../../../../../../Users/arob/Desktop/open/scalius-commerce-lite/packages/shared/src/plugins/scopes.ts
var PRODUCTS_READ = ["products.view", "categories.view", "collections.view", "attributes.view"];
var INVENTORY_READ = ["inventory.view"];
var OBJECTS_READ = ["objects.view"];
var PLUGIN_SCOPES = {
  /** Products, variants with their stock totals and per-location levels, collections, categories, brands and attributes. */
  read_products: { rbac: PRODUCTS_READ, staff: "products.view" },
  /**
   * Create, edit, trash and restore products, variants, collections,
   * categories, brands and attributes; set product custom fields. Never
   * changes stock (`write_inventory`). Permanently deletes only trashed
   * products, categories, brands and collections the app itself created
   * (`dashboard.resources.app_content.delete`), never the store's own.
   */
  write_products: {
    rbac: [
      ...PRODUCTS_READ,
      "products.create",
      "products.edit",
      "products.delete",
      "products.restore",
      "categories.create",
      "categories.edit",
      "categories.delete",
      "categories.restore",
      "collections.create",
      "collections.edit",
      "collections.delete",
      "collections.restore",
      "collections.toggle_status",
      "attributes.create",
      "attributes.edit",
      "attributes.delete"
    ],
    staff: "products.edit"
  },
  /** Stock levels per location, locations, suppliers and transfers; purchase orders also need `read_product_costs`. */
  read_inventory: { rbac: INVENTORY_READ, staff: "inventory.view" },
  /**
   * Adjust and set stock (on hand, per location), including the quantities a
   * product or SKU write sets; manage locations, suppliers and transfers
   * (purchase orders also need `read_product_costs`).
   */
  write_inventory: { rbac: [...INVENTORY_READ, "products.adjust_stock", "inventory.manage"], staff: "products.adjust_stock" },
  /** Orders, their lines, payments, shipments, returns and timeline; abandoned checkouts. Contact fields need the protected data scopes. */
  read_orders: { rbac: ["orders.view"], staff: "orders.view" },
  /**
   * Create orders, change their status and details, add timeline notes, set
   * order custom fields; request, approve, receive and cancel item returns
   * (receiving restocks what comes back, through the stock ledger).
   */
  write_orders: { rbac: ["orders.view", "orders.create", "orders.edit", "orders.change_status"], staff: "orders.edit" },
  /**
   * Record money received against an invoice (pay-later) order: a bank
   * transfer, cheque or cash. Sensitive: a recorded payment settles the order
   * with no money passing through the store. Gift cards and downloads on an
   * order an app marked paid wait for staff to release a review hold.
   * Charging a saved card is `write_payment_methods`.
   */
  write_payments: { rbac: ["orders.view", "orders.record_payment"], staff: "orders.record_payment", sensitive: true },
  /**
   * Charge a customer's saved payment method for an order with money due,
   * without the customer (a subscription renewal, through its provider), and
   * capture or void an authorized payment. Only the methods kept for this
   * app's own purchase option: an app never sees or charges a method another
   * app (or staff) kept. Lists and removes those methods (brand, last four
   * digits and expiry; never the provider's reference). Sensitive: it takes
   * a buyer's money while they are away.
   */
  write_payment_methods: {
    rbac: ["orders.view", "orders.charge_saved_methods"],
    staff: "orders.charge_saved_methods",
    sensitive: true
  },
  /**
   * Give money back on an order (`refunds.create`): through the payments it
   * came from or as store credit, never to a destination the app names, with
   * the order lines it is for. Sensitive: it moves money out of the store.
   */
  write_refunds: { rbac: ["orders.view", "orders.refund"], staff: "orders.refund", sensitive: true },
  /** Hand over order lines, create and void fulfilments and courier shipments. */
  write_fulfillments: { rbac: ["orders.view", "orders.manage_shipments"], staff: "orders.manage_shipments" },
  /**
   * Give a buyer the download or licence keys their paid order line bought
   * (as the store's automatic delivery would), give back access that was
   * taken away, and take it away (`digital_access.grant`, `.revoke`). Taking
   * it away cannot be undone by the buyer: the consent screen marks it
   * destructive. Reading an order's access is `read_orders`.
   */
  write_digital_access: { rbac: ["orders.view", "orders.manage_digital_access"], staff: "orders.manage_digital_access" },
  /**
   * Issue the app's coverage of units of an order line as the store's own
   * warranty records (`warranties.issue`), which buyers see and claim like
   * any warranty, and void units' coverage when they are cancelled,
   * refunded or returned (`warranties.void`). Voiding ends a buyer's cover:
   * the consent screen marks it destructive. Reading an order's warranties
   * is `read_orders`.
   */
  write_warranties: { rbac: ["orders.view", "orders.manage_warranties"], staff: "orders.manage_warranties" },
  /** Customers, their tags, saved segments and marketing consent; email, text or push a customer by id (`ctx.messaging`). Contact fields need the protected data scopes. */
  read_customers: { rbac: ["customers.view"], staff: "customers.view" },
  /** Create and edit customers, their tags and custom fields; save and change customer segments (not one a live discount or price list uses, without that area's write scope). */
  write_customers: { rbac: ["customers.view", "customers.create", "customers.edit"], staff: "customers.edit" },
  /** Send marketing email and SMS to customers who agreed to receive it. The platform resolves the address; the app never sees it. */
  write_marketing: { rbac: ["marketing.send"], staff: "marketing.send" },
  /**
   * Email and text any address from the store's sender (`ctx.messaging` with
   * any `to`). Without it an app reaches customers by id, the store's staff
   * and the addresses in its declared `messaging.recipients` fields only.
   * Sensitive: mail from the store's own domain to anyone. Confers no RBAC.
   */
  send_messages_any: { rbac: [], staff: "marketing.send", sensitive: true },
  /** Buyers' and recipients' names. */
  read_customer_names: { rbac: [], staff: "customers.view", protects: "name" },
  /** Buyers' email addresses. */
  read_customer_emails: { rbac: [], staff: "customers.view", protects: "email" },
  /** Buyers' and recipients' phone numbers. */
  read_customer_phones: { rbac: [], staff: "customers.view", protects: "phone" },
  /** Street addresses: address lines, company and neighbourhood (the region is not protected). */
  read_customer_addresses: { rbac: [], staff: "customers.view", protects: "address" },
  /** Discounts and their rules. */
  read_discounts: { rbac: ["discounts.view"], staff: "discounts.view" },
  /** Create, edit, pause, activate and archive discounts. */
  write_discounts: {
    rbac: ["discounts.view", "discounts.create", "discounts.edit", "discounts.delete", "discounts.toggle_status"],
    staff: "discounts.edit"
  },
  /** Content pages. */
  read_content: { rbac: ["pages.view"], staff: "pages.view" },
  /** Create, edit, publish and trash content pages; set their custom fields. */
  write_content: { rbac: ["pages.view", "pages.create", "pages.edit", "pages.delete", "pages.publish"], staff: "pages.edit" },
  /** The store's object types and records outside the app's own namespace (`custom.*`). */
  read_objects: { rbac: OBJECTS_READ, staff: "objects.view" },
  /** Create, edit and delete records of the store's object types. */
  write_objects: { rbac: [...OBJECTS_READ, "objects.edit"], staff: "objects.edit" },
  /** Files in the media library. */
  read_files: { rbac: ["media.view"], staff: "media.view" },
  /** Import files from an HTTPS address, rename, move and trash them; permanently delete trashed files the app itself imported. */
  write_files: { rbac: ["media.view", "media.upload", "media.delete", "media.manage_folders"], staff: "media.upload" },
  /** Gift cards: balances, transactions, owners and recipients (the code stays masked; recipient contacts need the protected data scopes). */
  read_gift_cards: { rbac: ["gift_cards.view"], staff: "gift_cards.view" },
  /**
   * Issue gift cards, adjust their balances, disable, enable and change
   * expiry. Sensitive: it creates and moves stored value the store owes, so
   * what one app adds a day stays within the merchant's limit. The app never
   * sees a card's code; the store delivers it to the owning customer only,
   * and an app never moves a card with a balance to another owner.
   */
  write_gift_cards: { rbac: ["gift_cards.view", "gift_cards.manage"], staff: "gift_cards.manage", sensitive: true },
  /**
   * Create, edit and delete the app's own webhook subscriptions: endpoints on
   * its approved hosts, for the event topics and the customer data its grant
   * already covers. Never sees or changes the store's other webhooks.
   * Sensitive: store events leave the store.
   */
  write_webhooks: { rbac: ["webhooks.view", "webhooks.manage"], staff: "webhooks.manage", sensitive: true },
  /**
   * Store settings: business details, web addresses, markets, languages,
   * delivery zones and their rates, tax regions and custom field definitions.
   */
  read_settings: { rbac: ["settings.general.view", "settings.shipping_methods.view", "taxes.view"], staff: "settings.general.view" },
  /**
   * Read the theme and change its shared draft: apply the app's own
   * template (its look and homepage) and set section settings, each under
   * the draft revision it read, with a restore point. Never publishes: what
   * buyers see changes only when staff publish the draft. Sensitive: the
   * draft is the next storefront. Confers `settings.theme.edit` only, never
   * the store's business, country or media settings.
   */
  write_themes: { rbac: ["settings.theme.edit"], staff: "settings.theme.edit", sensitive: true },
  /**
   * Read menus, create them, replace their links (up to three levels) and
   * publish them. Never chooses where a menu shows (header, footer).
   * Sensitive: a published menu placed in the header or footer changes what
   * buyers see at once.
   */
  write_navigation: { rbac: ["settings.header.edit"], staff: "settings.header.edit", sensitive: true },
  /** Add and update delivery places (a place dataset) through the place import; never delete them. */
  write_places: {
    rbac: ["settings.delivery_locations.view", "settings.delivery_locations.import"],
    staff: "settings.delivery_locations.import"
  },
  /**
   * What the store pays for stock: purchase-order costs (unit costs,
   * shipping, other charges and tax) and the SKU unit costs a receipt may
   * move. Alone it reaches no stable operation (a bundled first-party app
   * also reads inventory valuation with it): beside `read_inventory` it reads
   * purchase orders, beside `write_inventory` it drafts, orders, receives and
   * cancels them, and an app's webhooks for purchase orders need it.
   * Sensitive: costs and margins are the merchant's trade secrets.
   */
  read_product_costs: { rbac: ["products.view_costs"], staff: "products.view_costs", sensitive: true },
  /**
   * The inbox: threads (order, store and chat-channel threads) with their
   * messages, staff notes included, and `conversation.message_received`.
   * The contact's name and address need `read_customer_names` and
   * `read_customer_phones`. Sensitive: buyers' own words.
   */
  read_conversations: { rbac: ["conversations.view"], staff: "conversations.view", sensitive: true },
  /**
   * Reply in a thread and add staff notes (`conversations.create_message`):
   * a public reply reaches the buyer by the thread's own way (email for
   * storefront threads, the chat channel for channel threads), as a staff
   * reply does, and names the app. Sensitive: it speaks for the store.
   */
  write_conversations: { rbac: ["conversations.view", "conversations.reply"], staff: "conversations.reply", sensitive: true },
  /**
   * Send money to payees (`payouts.create`) through a payout provider the
   * merchant installed, and read the payouts the app sent (never another
   * app's). Sensitive: it moves money out of the store.
   */
  write_payouts: { rbac: ["payouts.manage"], staff: "payouts.manage", sensitive: true },
  /**
   * The staff directory: each staff member's id, name, roles and whether
   * they are active, so an app attributes work (who rang up a sale). Never an
   * email, a phone, sign-in details or what they may do.
   */
  read_staff: { rbac: ["staff.view"], staff: "staff.view" },
  /** Product reviews: ratings, text, photos, replies and moderation state. The reviewer's name needs `read_customer_names`. */
  read_reviews: { rbac: ["reviews.view"], staff: "reviews.view" },
  /** Import reviews (a reviews app, a move from another platform) and publish, reject or hide them. */
  write_reviews: { rbac: ["reviews.view", "reviews.moderate"], staff: "reviews.moderate" },
  /** Sales numbers over a bounded period: orders, revenue, average order value and, where the store records them, sessions. */
  read_analytics: { rbac: ["dashboard.analytics"], staff: "dashboard.analytics" }
};
var PLUGIN_SCOPE_NAMES = Object.keys(PLUGIN_SCOPES);

// ../../../../../../../../Users/arob/Desktop/open/scalius-commerce-lite/packages/plugin-sdk/src/ui.ts
function document(root) {
  return { version: 1, root };
}
var ui = {
  /** A full app page (admin); `children` are its sections, cards and tables. */
  page: (children, options = {}) => document({ type: "page", ...options, children }),
  /** A resource card or home widget body (admin), or a UI slot's content (buyer). */
  view: (children) => document({ type: "stack", children }),
  section: (title, children, options = {}) => ({ type: "section", title, ...options, children }),
  card: (title, children, options = {}) => ({ type: "card", title, ...options, children }),
  /**
   * Children in a column, or a row with `direction: "horizontal"`: a vertical
   * stack in a row takes the room left. `tone` (buyer) draws it on a toned
   * surface: an offer row, a status box (`ui.stack([ui.mark("warning"), ui.stack([…]), ui.button(…)], { direction: "horizontal", tone: "warning" })`).
   */
  stack: (children, options = {}) => ({ type: "stack", ...options, children }),
  columns: (children) => ({ type: "columns", children }),
  heading: (text, level = 2) => ({ type: "heading", text, level }),
  /**
   * Words, or a sentence of pieces whose links are drawn inside it:
   * `ui.text([{ text: "Covers repairs. " }, { text: "Read the terms", to: ui.to.store("/pages/protection") }])`.
   * Plain pieces keep their spaces; a link's words are a link's (1 to 120 characters).
   */
  text: (text, options = {}) => ({ type: "text", text: typeof text === "string" ? text : [...text], ...options }),
  badge: (text, tone = "neutral") => ({ type: "badge", text, tone }),
  banner: (tone, text, options = {}) => ({ type: "banner", tone, text, ...options }),
  keyValue: (items) => ({ type: "key-value", items }),
  stat: (label, value, help) => ({ type: "stat", label, value, ...help ? { help } : {} }),
  /**
   * A progress bar at `value` of `max` with its percentage (admin), e.g. a
   * background job's `progress.done` of `progress.total`. `live: true`
   * makes the dashboard read the surface again every few seconds while it is
   * shown, so the bar moves on its own; leave it off once the job is done.
   */
  progress: (label, value, max, options = {}) => ({ type: "progress", label, value, max, ...options }),
  table: (options) => ({ type: "table", ...options }),
  empty: (title, options = {}) => ({ type: "empty-state", title, ...options }),
  /** An https URL (admin), or `{ media }` / `{ app: "public/…" }` (buyer). */
  image: (src, alt, options = {}) => ({ type: "image", src, alt, ...options }),
  link: (text, to) => ({ type: "link", text, to }),
  /** A tone's glyph in a circle beside words that say the same (buyer): "!", a tick, "i", "×" or a dot. */
  mark: (tone) => ({ type: "mark", tone }),
  divider: () => ({ type: "divider" }),
  /**
   * A summary line the buyer opens to show `children` (buyer): the browser's
   * own disclosure, so it opens with a click or the keyboard and without
   * scripts. `open: true` draws it open.
   */
  disclosure: (summary, children, options = {}) => ({ type: "disclosure", summary, ...options, children }),
  /** A button: `ui.route(…)`, `ui.navigate(…)` or a `ui.cart.*` operation. */
  button: (label, action, options = {}) => ({ type: "button", label, action, ...options }),
  /** A form (admin) that sends its values to one of this app's routes. */
  form: (action, submitLabel, children, options = {}) => ({ type: "form", action, submitLabel, ...options, children }),
  textField: (name, label, options = {}) => ({ type: "text-field", name, label, ...options }),
  textarea: (name, label, options = {}) => ({ type: "textarea", name, label, ...options }),
  numberField: (name, label, options = {}) => ({ type: "number-field", name, label, ...options }),
  select: (name, label, options, rest = {}) => ({ type: "select", name, label, options, ...rest }),
  checkbox: (name, label, options = {}) => ({ type: "checkbox", name, label, ...options }),
  dateField: (name, label, options = {}) => ({ type: "date-field", name, label, ...options }),
  /**
   * A file staff choose (admin), e.g. a CSV to import: the form sends its
   * upload id under `name`; hand it to a job and read it with `ctx.uploads.read`.
   */
  fileField: (name, label, options = {}) => ({ type: "file-field", name, label, ...options }),
  /** One of the app's `checkout.attributes`, drawn as the store's own input (buyer). */
  /**
   * One of the app's checkout attributes, drawn by the store. `choices`
   * (a `text` attribute only, at most 50) offers what the extension computed
   * now, such as the open delivery slots from a list read; the app's
   * `cart.validate` still checks the answer.
   */
  field: (attribute, options = {}) => ({
    type: "field",
    attribute,
    ...options.choices ? { choices: options.choices } : {}
  }),
  /** A request to one of this app's routes: an admin route (admin), a public route through the store's proxy (buyer). */
  route: (route, options = {}) => ({ kind: "route", route, ...options }),
  /** Opens a page (`ui.to.*`). */
  navigate: (to) => ({ kind: "navigate", to }),
  /** Cart operations (buyer, on the cart and checkout pages). */
  cart: {
    addLine: (variantId, quantity = 1) => ({ kind: "cart", op: "add_line", variantId, quantity }),
    applyCode: (code) => ({ kind: "cart", op: "apply_code", code }),
    /** Sets one of the app's checkout attributes. */
    setAttribute: (key, value) => ({ kind: "cart", op: "set_attribute", key, value }),
    /**
     * Sets one of the app's own line inputs (`checkout.lineInputs` key) to
     * `value` on the named cart lines (`line.lineKey` of `input.lines` in a
     * `cart.line.after` extension), or on every line it applies to. The store
     * checks it as its own cart controls do: a choice that needs confirmation
     * asks in the store's dialog, and the line is priced again.
     */
    setLineInput: (key, value, lineKeys) => ({ kind: "cart", op: "set_line_input", key, value, ...lineKeys ? { lineKeys } : {} }),
    /** Clears one of the app's own line inputs from the named lines, or from every line that has an answer. */
    clearLineInput: (key, lineKeys) => ({ kind: "cart", op: "set_line_input", key, value: null, ...lineKeys ? { lineKeys } : {} })
  },
  /** Where links go: a Scalius resource page, one of this app's pages or an https site (admin); a path on the store (buyer). */
  to: {
    resource: (resource, id) => ({ kind: "resource", resource, id }),
    page: (page, query) => ({ kind: "app-page", page, ...query ? { query } : {} }),
    external: (href) => ({ kind: "external", href }),
    store: (path) => ({ kind: "store", path })
  },
  /** What a button's or form's admin route answers. */
  result: (result) => {
    const { toast, ...rest } = result;
    return { ...rest, ...toast === void 0 ? {} : { toast: typeof toast === "string" ? { message: toast, tone: "success" } : toast } };
  }
};

// ../../../../../../../../Users/arob/Desktop/open/scalius-commerce-lite/packages/plugin-sdk/src/index.ts
function readOne(reads, as) {
  const value = reads?.[as];
  return value && typeof value === "object" && "data" in value && "revision" in value && typeof value.revision === "number" ? value : null;
}
function readList(reads, as) {
  const value = reads?.[as];
  return Array.isArray(value) ? value : [];
}
function definePlugin(definition) {
  return definition;
}
function provider(kind) {
  return (implementation) => Object.freeze({ ...implementation, kind });
}
var definePaymentProvider = provider("payment");
var defineCourierProvider = provider("courier");
var defineSmsProvider = provider("sms");
var defineEmailProvider = provider("email");
var defineCourierHistoryProvider = provider("courier_history");
var defineTaxProvider = provider("tax");
var defineTranslationProvider = provider("translation");
var defineAiProvider = provider("ai");
var defineMessagingProvider = provider("messaging");
var definePushProvider = provider("push");
var defineSearchProvider = provider("search");
var defineAddressProvider = provider("address");
var defineFxProvider = provider("fx");
var defineIdentityProvider = provider("identity");
var definePayoutProvider = provider("payout");

// src/index.ts
var manifest = {
  id: "acme.delivery-slots",
  name: "Delivery slots",
  version: "0.2.0",
  apiVersion: PLUGIN_API_VERSION,
  description: "Buyers choose a delivery day and window at checkout; each slot takes only as many orders as it has room for.",
  author: { name: "Scalius" },
  tagline: "Dated delivery slots with limited room",
  categories: ["shipping"],
  support: { url: "https://github.com/scaliuslabs/scalius-commerce-lite/issues" },
  minPlatformVersion: "1.0.0",
  checkout: {
    attributes: [
      { key: "day", label: "Delivery day", type: "date" },
      {
        key: "window",
        label: "Delivery window",
        type: "choice",
        choices: [
          { value: "am", label: "Morning" },
          { value: "pm", label: "Afternoon" },
          { value: "eve", label: "Evening" }
        ]
      }
    ]
  },
  functions: [
    {
      point: "cart.validate",
      priority: 100,
      onError: "block",
      reads: [{ as: "slot", object: "slots", key: { join: ["attribute.day", "attribute.window"] } }]
    }
  ],
  storefront: {
    extensions: [{
      target: "checkout.contact.after",
      reads: [{ as: "open", object: "slots", list: { orderBy: "starts_at", from: "now", limit: 30 } }]
    }]
  },
  objects: {
    // Record id: `<day>:<window>` (`2026-11-10:am`), the window one of the declared choices. `{ label, starts_at, capacity, taken }`.
    slots: {
      name: "Slots",
      fields: [
        { key: "label", name: "Label", type: "single_line_text" },
        { key: "starts_at", name: "Starts at", type: "date_time" },
        { key: "capacity", name: "Capacity", type: "integer" },
        { key: "taken", name: "Taken", type: "integer" }
      ],
      indexes: ["starts_at"]
    }
  },
  translations: {
    bn: {
      name: "ডেলিভারি স্লট",
      tagline: "সীমিত জায়গার তারিখসহ ডেলিভারি স্লট",
      description: "ক্রেতা চেকআউটে ডেলিভারির দিন ও সময় বেছে নেন; প্রতিটি স্লটে যত জায়গা, তত অর্ডারই নেওয়া হয়।",
      checkout: {
        attributes: {
          day: { label: "ডেলিভারির দিন" },
          window: { label: "ডেলিভারির সময়", choices: { am: "সকাল", pm: "বিকেল", eve: "সন্ধ্যা" } }
        }
      }
    }
  }
};
var whole = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? value : 0;
var hasRoom = (slot) => whole(slot.taken) < whole(slot.capacity);
var started = (slot, now) => !now || Date.parse(slot.starts_at) <= Date.parse(now);
function openSlots(reads, now) {
  const days = /* @__PURE__ */ new Map();
  for (const record of readList(reads, "open")) {
    const slot = record.data;
    const [day, window] = record.id.split(":");
    if (!day || !window || started(slot, now) || !hasRoom(slot)) continue;
    days.set(day, [...days.get(day) ?? [], { window, label: slot.label }]);
  }
  return days;
}
var src_default = definePlugin({
  manifest,
  functions: {
    "cart.validate": ({ cart, reads, now }) => {
      if (cart.lines.length === 0) return { errors: [] };
      if (!cart.attributes["acme.delivery-slots.day"] || !cart.attributes["acme.delivery-slots.window"]) {
        return { errors: [{ code: "slot_required", message: "Choose a delivery day and window." }] };
      }
      const slot = readOne(reads, "slot");
      if (!slot) return { errors: [{ code: "slot_unknown", message: "That delivery slot is not offered. Choose another." }] };
      if (started(slot.data, now)) return { errors: [{ code: "slot_closed", message: "That delivery slot has started. Choose a later one." }] };
      if (!hasRoom(slot.data)) return { errors: [{ code: "slot_full", message: "That delivery slot is full. Choose another." }] };
      return { errors: [], commit: [{ as: "slot", record: { ...slot.data, taken: whole(slot.data.taken) + 1 } }] };
    }
  },
  extensions: {
    "checkout.contact.after": ({ reads, now, attributes }) => {
      const days = openSlots(reads, now);
      if (days.size === 0) return { ui: ui.view([ui.text("No delivery slots are open right now.")]) };
      const day = attributes.day && days.has(attributes.day) ? attributes.day : [...days.keys()][0];
      return {
        ui: ui.view([
          // Each labelled with its own value: the buyer reads the day in their format and the window's (translated) label.
          ui.field("day", { choices: [...days.keys()].map((value) => ({ value, label: value })) }),
          ui.field("window", { choices: days.get(day).map((slot) => ({ value: slot.window, label: slot.window })) })
        ])
      };
    }
  }
});
export {
  src_default as default,
  manifest,
  openSlots
};
